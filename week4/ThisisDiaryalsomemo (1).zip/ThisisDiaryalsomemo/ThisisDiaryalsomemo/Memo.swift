//
//  Memo.swift
//  ThisisDiaryalsomemo
//
//  Created by mac on 2022/10/11.
//

import Foundation

struct Memo {
    var title: String
    
    
}
