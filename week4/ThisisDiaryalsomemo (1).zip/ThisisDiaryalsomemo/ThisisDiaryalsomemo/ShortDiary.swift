//
//  ShortDiary.swift
//  ThisisDiaryalsomemo
//
//  Created by mac on 2022/10/11.
//

import Foundation

struct Task {
    var title: String
    var context: String
    var date: Date
    
}
