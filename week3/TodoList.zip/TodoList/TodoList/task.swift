//
//  task.swift
//  TodoList
//
//  Created by mac on 2022/06/30.
//

import Foundation

struct Task {
    var title: String
    var done: Bool
}
